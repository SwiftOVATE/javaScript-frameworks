export const FullPage = () => {
    return (
        <div className="fullpage h-screen">
            <div className="bg-green-100 h-screen">d</div>
            <div className="bg-red-100 h-screen">d</div>
            <div className="bg-green-100 h-screen">d</div>
        </div>
    )
}