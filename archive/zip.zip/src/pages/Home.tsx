import { Card } from "flowbite-react"

export const Home = () => {
    return (
        <div className="h-screen container mx-auto">
            <Card className="w-2/3 mx-auto m-10">
                <h5 className="text-center text-5xl">
                    Home Page
                </h5>
            </Card >
        </div >
    )
}