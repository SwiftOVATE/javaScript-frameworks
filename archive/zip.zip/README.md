# Getting Started with Create React App

This project was bootstrapped with [Create react App](https://github.com/facebook/create-react-app).

Build with `Tailwind`

```bash
npx create-react-app my-app --template typescript
```

### `npm start`

```bash
npm start
```

Runs the app in the development mode.

Open [http://localhost:3000](http://localhost:3000) to view it in the browser.
